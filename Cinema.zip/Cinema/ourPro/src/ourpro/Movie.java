/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ourpro;
import java.util.ArrayList;

public class Movie {

    private String name;
    private int leastAge;
    private int duration;
    private int rating;
    public static ArrayList<Costumer> costumersArr = new ArrayList<Costumer>();
    String theater[][] = createTheater();

    public Movie(String name, int leastAge, int duration, int rating) {
        this.name = name;
        this.leastAge = leastAge;
        this.duration = duration;
        this.rating = rating;
        takeSeates() ; 
    }

    Movie() {
    };

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getLeastAge() {
        return this.leastAge;
    }

    public void setLeastAge(int leastAge) {
        this.leastAge = leastAge;
    }

    public int getDuration() {
        return this.duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    public int getRating() {
        return this.rating;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }



    public void bookSeat(int columnIndex, int rowIndex) {

        this.theater[columnIndex][rowIndex] = "XXX";

    }
     // ! Overloading                           
    public void bookSeat(String seat) { 
        int columnIndex = -1;
        int rowIndex = -1;

        for (int i = 0; i < this.theater.length; i++) {
            for (int j = 0; j < this.theater[i].length; j++) {
                // ! Cabital Or Small
                if ((this.theater[i][j].charAt(0) == seat.charAt(0)
                        || this.theater[i][j].charAt(0) + 32 == seat.charAt(0))
                        && this.theater[i][j].substring(1).equalsIgnoreCase(seat.substring(1))) {

                    columnIndex = i;
                    rowIndex = j;
                    break;

                } 
                
                
            }
        }

        if (columnIndex == -1 || rowIndex == -1) {
        } else {
            bookSeat(columnIndex, rowIndex);
        }

    }
    
    // True Or False
    public boolean isTaken(String seat) {
        int columnIndex = -1;
        int rowIndex = -1;

        for (int i = 0; i < this.theater.length; i++) {
            for (int j = 0; j < this.theater[i].length; j++) {
                if ((this.theater[i][j].charAt(0) == seat.charAt(0)
                        || this.theater[i][j].charAt(0) + 32 == seat.charAt(0))
                        && this.theater[i][j].substring(1).equalsIgnoreCase(seat.substring(1))) {

                    columnIndex = i;
                    rowIndex = j;
                    break;

                }
            }
        }

        if (columnIndex != -1 && rowIndex != -1) {
        // ex: C7    
            return false;
        } else {
        // ex: xxx
            return true;
        }
    }

    private String[][] createTheater() {
        String theater[][] = new String[14][16];
        for (int i = 0; i < theater.length; i++) {
            for (int j = 0; j < theater[i].length; j++) {
                theater[i][j] = ((char) (65 + i)) + "" + j + "";
            }
        }

        return theater;
    }

    public void displayTheatre() {
        for (int i = 0; i < this.theater.length; i++) {
            for (int j = 0; j < this.theater[i].length; j++) {
                System.out.printf("%5s", this.theater[i][j]);
            }
            System.out.println();
        }
    }

    public void takeSeates(){
        for(int i = 0 ; i < costumersArr.size() ; i++){
            bookSeat(costumersArr.get(i).seat) ; 
        }
    }

}

