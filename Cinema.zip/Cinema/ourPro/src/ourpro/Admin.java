/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ourpro;

/**
 *
 * @author Lenovo
 */
public class Admin extends Person {

    private String email;
    private String password;

    Admin(String name , int age  , String email , String password ) {
        super(name , age) ; 
        this.email = email ; 
        this.password = password;   

    }

    

    @Override
    public String getName() {
        return this.name;
    }

    @Override
    public int getAge() {
        return this.age;
    }

    public String getEmail(){
        return this.email ; 
    }

    public String getPassowrd(){
        return this.password ; 
    }


    public static void runAdmin(){
        
        System.out.println("--------   Admin Menu   --------");
        System.out.println("1 - Add New Movie .");
        System.out.println("2 - Display All Costumers .");
        System.out.println("3 - Delete Movie .");
        System.out.println("0 - Exit .");
        System.out.print("What Would You Like To Do : ");
        int choice = Main.scanner.nextInt() ; 
        
        switch(choice){
            case 1 :   
                Operations.addMovie();
                break ;
            case 2 :    
                Operations.showCostumers() ; 
                break ;
            case 3 : 
                Operations.deleteMovie();
                break ; 
            case 0 : 
                break ;
            default :   
                System.out.println("Wrong Input Please Try Again ... ");
                Main.scanner.nextInt() ; 
        }

        if(choice != 0 ){
            runAdmin() ; 
        }


    }


}

