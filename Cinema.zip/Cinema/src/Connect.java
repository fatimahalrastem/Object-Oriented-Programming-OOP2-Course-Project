
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import java.sql.*;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Agarwal
 */
public class Connect {
    Connection con=null;
      
        public static Connection ConnectDB(){
        try{
              String currentDirectory = System.getProperty("user.dir");
             String username="root";
        String password="12345";
            
//             Class.forName("com.mysql.jdbc.Driver"); 

           Connection con =DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/cinemasyt",username,password);
           // Connection con=DriverManager.getConnection("jdbc:derby://localhost:1527/cinemasyt","test","test");
//            JOptionPane.showMessageDialog(null, "connected");
           return con;
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
            return null;
        }      
    }
}
